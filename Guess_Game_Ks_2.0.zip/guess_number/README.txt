Project: Guess The Number (Django)

See top-level README.md for full setup instructions.

