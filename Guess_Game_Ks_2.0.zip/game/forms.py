from django import forms

from .models import GameSession


class GameSessionDeleteForm(forms.Form):
    game_session_id = forms.IntegerField(widget=forms.HiddenInput())

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        instance_id = self.initial.get('game_session_id')

    def clean_game_session_id(self):
        game_session_id = self.cleaned_data['game_session_id']
        # Existence check happens in the view.
        return game_session_id

