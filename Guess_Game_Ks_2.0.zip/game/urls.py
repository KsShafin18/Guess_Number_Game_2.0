from django.urls import path
from . import views

urlpatterns = [
    path('', views.enter_name, name='enter_name'),
    path('start/', views.start_game, name='start_game'),
    path('guess/', views.make_guess, name='make_guess'),
    path('success/', views.success, name='success'),
    path('admin-panel/', views.admin_panel, name='admin_panel'),
    path('admin-back-to-game/', views.admin_back_to_game, name='admin_back_to_game'),
]


