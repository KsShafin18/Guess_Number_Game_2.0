from django.db import models


class Player(models.Model):
    name = models.CharField(max_length=150, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.name


class GameSession(models.Model):
    player = models.ForeignKey(Player, on_delete=models.CASCADE, related_name="games")

    # The number that the computer finally guessed as "correct".
    guessed_number = models.PositiveIntegerField()

    # Attempts taken by the computer until the player pressed "Correct".
    attempts = models.PositiveIntegerField()

    # Total points awarded for this game.
    points = models.IntegerField()

    # Stored for audit/leaderboard needs.
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"{self.player.name} - {self.guessed_number} ({self.points} pts)"

