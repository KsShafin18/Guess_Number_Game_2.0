from django.shortcuts import render, redirect
from django.db.models import Sum
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import logout
from django.contrib.auth.views import LoginView
from django.core.paginator import Paginator


from .models import Player, GameSession



# Beginner-friendly views using session state, but persist finished games in DB.

def _init_game_session(request):
    """Initialize session values for a new game."""
    request.session['min_num'] = 1
    request.session['max_num'] = 100
    request.session['attempts'] = 0

    # Binary search initial guess.
    guess = (request.session['min_num'] + request.session['max_num']) // 2
    request.session['current_guess'] = guess

    # Track the full sequence of computer guesses to apply the -50 penalty.
    request.session['computer_guess_history'] = [guess]


def _compute_points(attempts: int, computer_guess_history, final_number: int) -> int:
    """Compute points with your rules.

    Rules:
    - +75 points per attempt.
    - -50 penalty per extra attempt after the computer already suggested
      the correct number earlier.
    """
    base = attempts * 75

    # Find the first time the computer suggested the correct number.
    first_index = None
    for idx, n in enumerate(computer_guess_history):
        if n == final_number:
            first_index = idx
            break

    if first_index is None:
        # Should never happen, but keep safe.
        return base

    # attempts counts how many user responses happened (i.e., how many guesses were tested).
    # The correct number appears at `first_index` in computer history (0-based).
    extra_attempts = attempts - (first_index + 1)
    penalty = extra_attempts * 50 if extra_attempts > 0 else 0

    return base - penalty


def enter_name(request):
    """Landing page: ask user for their name."""
    # If a previous game is completed and they return, clear state.
    request.session.pop('final_number', None)
    request.session.pop('finished', None)
    request.session.pop('computer_guess_history', None)

    return render(request, 'game/enter_name.html')


def start_game(request):
    """Create a new game session and start guessing."""
    name = (request.POST.get('name') or '').strip()
    if not name:
        return redirect('enter_name')

    request.session['player_name'] = name
    request.session.pop('final_number', None)
    request.session.pop('finished', None)

    _init_game_session(request)
    return redirect('make_guess')


def make_guess(request):
    """Handle Higher/Lower/Correct actions and compute the next guess."""
    if not request.session.get('player_name'):
        return redirect('enter_name')

    # If game already finished, show success.
    if request.session.get('finished'):
        return redirect('success')

    min_num = request.session.get('min_num', 1)
    max_num = request.session.get('max_num', 100)
    attempts = request.session.get('attempts', 0)
    current_guess = request.session.get('current_guess', (min_num + max_num) // 2)
    computer_guess_history = request.session.get('computer_guess_history', [current_guess])

    if request.method == 'POST':
        action = request.POST.get('action')

        # Count attempts only when user responds to a guess.
        attempts += 1

        if action == 'higher':
            # User says the real number is higher than our guess.
            min_num = current_guess + 1
        elif action == 'lower':
            # User says the real number is lower than our guess.
            max_num = current_guess - 1
        elif action == 'correct':
            final_number = current_guess
            request.session['final_number'] = final_number
            request.session['attempts'] = attempts
            request.session['finished'] = True

            points = _compute_points(
                attempts=attempts,
                computer_guess_history=computer_guess_history,
                final_number=final_number,
            )
            request.session['points'] = points

            # Save player + game in DB.
            player_name = request.session['player_name']
            player, _ = Player.objects.get_or_create(name=player_name)
            GameSession.objects.create(
                player=player,
                guessed_number=final_number,
                attempts=attempts,
                points=points,
            )

            return redirect('success')

        # Update session bounds.
        request.session['min_num'] = min_num
        request.session['max_num'] = max_num
        request.session['attempts'] = attempts

        # Next guess using binary search.
        if min_num > max_num:
            # Safety: inconsistent user input.
            _init_game_session(request)
            return redirect('make_guess')

        next_guess = (min_num + max_num) // 2
        request.session['current_guess'] = next_guess

        # Record guess sequence.
        computer_guess_history.append(next_guess)
        request.session['computer_guess_history'] = computer_guess_history

        return redirect('make_guess')

    # GET request: show the current guess.
    context = {
        'name': request.session['player_name'],
        'guess': current_guess,
        'attempts': attempts,
        'min_num': min_num,
        'max_num': max_num,
    }
    return render(request, 'game/game.html', context)


def success(request):
    """Success page after user clicks Correct."""
    name = request.session.get('player_name')
    final_number = request.session.get('final_number')
    attempts = request.session.get('attempts', 0)
    points = request.session.get('points', 0)

    if not name or final_number is None:
        return redirect('enter_name')

    # Leaderboard: Top 10 players by highest total points.
    leaderboard_qs = (
        Player.objects.annotate(total_points=Sum('games__points'))
        .order_by('-total_points', 'name')
    )
    top10 = list(leaderboard_qs[:10])
    rest = list(leaderboard_qs[10:])

    return render(
        request,
        'game/success.html',
        {
            'name': name,
            'final_number': final_number,
            'attempts': attempts,
            'points': points,
            'top10': top10,
            'rest': rest,
        },
    )


def _is_superuser(user):
    return user.is_authenticated and user.is_superuser


@user_passes_test(_is_superuser)
def admin_back_to_game(request):
    """Logout admin and redirect back to the main game page."""
    logout(request)
    return redirect('enter_name')


@user_passes_test(_is_superuser)
def admin_panel(request):
    """Admin panel: search + sort + pagination over games."""

    # Handle delete actions (POST only)
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'delete_all_games':
            GameSession.objects.all().delete()
            return redirect('admin_panel')

        if action == 'delete_game':
            game_session_id = request.POST.get('game_session_id')
            if game_session_id:
                GameSession.objects.filter(id=game_session_id).delete()
            return redirect('admin_panel')


    q = (request.GET.get('q') or '').strip()

    sort = request.GET.get('sort') or 'points'
    page = int(request.GET.get('page') or '1')

    games_qs = GameSession.objects.select_related('player')

    if q:
        games_qs = games_qs.filter(player__name__icontains=q)

    # Sort by highest points (default). Secondary: newest.
    if sort == 'points':
        games_qs = games_qs.order_by('-points', '-created_at')
    else:
        games_qs = games_qs.order_by('-created_at')

    paginator = Paginator(games_qs, 10)
    page_obj = paginator.get_page(page)

    total_players = Player.objects.count()
    total_games = GameSession.objects.count()

    context = {
        'page_obj': page_obj,
        'q': q,
        'sort': sort,
        'total_players': total_players,
        'total_games': total_games,
    }
    return render(request, 'game/admin_panel.html', context)

