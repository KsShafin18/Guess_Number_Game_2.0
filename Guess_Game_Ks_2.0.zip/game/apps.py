from django.apps import AppConfig


class GameConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'game'

    def ready(self):
        # Seed default super admin account.
        from django.contrib.auth.models import User
        from django.db import transaction

        username = 'KsShafin'
        password = '1266'

        try:
            with transaction.atomic():
                user, created = User.objects.get_or_create(username=username)
                if created or not user.is_superuser:
                    user.is_superuser = True
                    user.is_staff = True
                    user.set_password(password)
                    user.save()
                elif not user.check_password(password):
                    user.set_password(password)
                    user.save()
        except Exception:
            # Avoid breaking server startup due to seeding issues.
            pass


